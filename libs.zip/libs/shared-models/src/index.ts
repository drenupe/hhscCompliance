// libs/shared-models/src/index.ts

// Re-export roles + RACI helpers from a single place.
// Nothing else should export ModuleKey / Raci / DEFAULT_RACI_MAP.

export * from './lib/auth/roles';
export * from './lib/raci';
