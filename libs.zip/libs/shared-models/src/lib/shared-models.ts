export function sharedModels(): string {
  return 'shared-models';
}
