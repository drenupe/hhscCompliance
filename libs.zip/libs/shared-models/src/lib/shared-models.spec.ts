import { sharedModels } from './shared-models';

describe('sharedModels', () => {
  it('should work', () => {
    expect(sharedModels()).toEqual('shared-models');
  });
});
