// libs/shared-models/src/lib/auth/roles.ts

export const ALL_ROLES = [
  'Admin',
  'CaseManager',
  'Nurse',
  'DirectCareStaff',
  'ISSManager',
  'ISSStaff',
  'Finance',
  'ProgramDirector',
  'ComplianceOfficer',
  'BehaviorSupportLead',
  'FinanceOfficer',
  'MedicalDirector',
] as const;

export type AppRole = (typeof ALL_ROLES)[number];
