// libs/shared-models/src/lib/raci.ts
import type { AppRole } from './auth/roles';

/**
 * Simple RACI shape used for seeding.
 * We keep it loose and only care that it contains valid AppRole strings.
 */
export interface Raci {
  R?: AppRole[]; // Responsible
  A?: AppRole[]; // Accountable
  C?: AppRole[]; // Consulted
  I?: AppRole[]; // Informed
}

/**
 * Default RACI map keyed by module "key" values.
 * Keys should match what you insert into modules_catalog (e.g. "residential", "issAttendance", etc.).
 */
export const DEFAULT_RACI_MAP: Record<string, Raci> = {
  residential: {
    R: ['DirectCareStaff'],
    A: ['CaseManager'],
    C: ['Admin'],
    I: ['Finance'],
  },
  programmatic: {
    R: ['CaseManager'],
    A: ['Admin'],
    C: ['DirectCareStaff'],
    I: ['Nurse'],
  },
  finance: {
    R: ['FinanceOfficer'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  behavior: {
    R: ['BehaviorSupportLead'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  ane: {
    R: ['DirectCareStaff'],
    A: ['Admin'],
    C: ['CaseManager', 'Nurse'],
    I: ['FinanceOfficer'],
  },
  restraints: {
    R: ['Nurse'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  enclosedBeds: {
    R: ['Nurse'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  protectiveDevices: {
    R: ['Nurse'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  prohibitions: {
    R: ['CaseManager'],
    A: ['Admin'],
    C: ['Nurse'],
    I: ['DirectCareStaff'],
  },
  medical: {
    R: ['Nurse'],
    A: ['MedicalDirector'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  staff: {
    R: ['Admin'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['DirectCareStaff'],
  },
  issAttendance: {
    R: ['ISSStaff'],
    A: ['ISSManager'],
    C: ['CaseManager'],
    I: ['Admin'],
  },
  issServicePlans: {
    R: ['ISSStaff'],
    A: ['ISSManager'],
    C: ['CaseManager'],
    I: ['Admin'],
  },
  issTransportation: {
    R: ['ISSStaff'],
    A: ['ISSManager'],
    C: ['CaseManager'],
    I: ['Admin'],
  },
  issIncidents: {
    R: ['ISSStaff'],
    A: ['ISSManager'],
    C: ['CaseManager', 'Nurse'],
    I: ['Admin'],
  },
  costReport: {
    R: ['FinanceOfficer'],
    A: ['Admin'],
    C: ['CaseManager'],
    I: ['MedicalDirector'],
  },
};
