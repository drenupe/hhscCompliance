// libs/shared-models/src/lib/ownership.ts
import type { ModuleKey } from './raci';

// Example of a distinct concept that doesn’t conflict with raci.ts
export type Owner = 'Business' | 'Clinical' | 'Admin';

export const MODULE_OWNERS: Record<ModuleKey, Owner> = {
  dashboard: 'Admin',
  residential: 'Clinical',
  programmatic: 'Business',
  finance: 'Business',
  behavior: 'Clinical',
  ane: 'Clinical',
  restraints: 'Clinical',
  enclosedBeds: 'Clinical',
  protectiveDevices: 'Clinical',
  prohibitions: 'Business',
  medical: 'Clinical',
  staff: 'Admin',
  policies: 'Admin',
  users: 'Admin',
  issAttendance: 'Business',
  issServicePlans: 'Business',
  issTransportation: 'Business',
  issIncidents: 'Business',
  costReport: 'Business',
};
