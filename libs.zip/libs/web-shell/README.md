# web-shell

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test web-shell` to execute the unit tests.
