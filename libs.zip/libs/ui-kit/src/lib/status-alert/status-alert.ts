import { Component } from '@angular/core';

@Component({
  selector: 'status-alert',
  imports: [],
  templateUrl: './status-alert.html',
  styleUrl: './status-alert.scss'
})
export class StatusAlert {

}
