import { Component } from '@angular/core';

@Component({
  selector: 'location-selector',
  imports: [],
  templateUrl: './location-selector.html',
  styleUrl: './location-selector.scss'
})
export class LocationSelector {

}
