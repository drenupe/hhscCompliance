import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-prohibitions',
  imports: [CommonModule],
  templateUrl: './prohibitions.html',
  styleUrl: './prohibitions.scss',
})
export class Prohibitions {}
