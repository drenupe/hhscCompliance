import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-cost-report',
  imports: [CommonModule],
  templateUrl: './lib.html',
  styleUrl: './lib.scss'
})
export class CostReport {}
