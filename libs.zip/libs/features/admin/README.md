# cost-report

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test cost-report` to execute the unit tests.
