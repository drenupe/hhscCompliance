import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-medical',
  imports: [CommonModule],
  templateUrl: './medical.html',
  styleUrl: './medical.scss',
})
export class Medical {}
