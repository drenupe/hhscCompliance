export * from './lib/routes/medical.routes';
export * from './lib/pages/nursing/nursing.page';
export * from './lib/pages/med-admin/med-admin.page';
