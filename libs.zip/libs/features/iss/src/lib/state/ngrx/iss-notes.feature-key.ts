export const ISS_NOTES_FEATURE_KEY = 'issNotes';
