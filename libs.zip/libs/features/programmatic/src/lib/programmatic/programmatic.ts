import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-programmatic',
  imports: [CommonModule],
  templateUrl: './programmatic.html',
  styleUrl: './programmatic.scss',
})
export class Programmatic {}
