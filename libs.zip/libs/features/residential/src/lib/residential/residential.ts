import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-residential',
  imports: [CommonModule],
  templateUrl: './residential.html',
  styleUrl: './residential.scss',
})
export class Residential {}
