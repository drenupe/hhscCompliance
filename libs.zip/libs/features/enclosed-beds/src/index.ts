export * from './lib/enclosed-beds/enclosed-beds';
