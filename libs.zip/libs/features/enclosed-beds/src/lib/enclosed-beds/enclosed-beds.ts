import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-enclosed-beds',
  imports: [CommonModule],
  templateUrl: './enclosed-beds.html',
  styleUrl: './enclosed-beds.scss',
})
export class EnclosedBeds {}
