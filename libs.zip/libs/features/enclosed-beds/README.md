# enclosed-beds

This library was generated with [Nx](https://nx.dev).

## Running unit tests

Run `nx test enclosed-beds` to execute the unit tests.
