import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-restraints',
  imports: [CommonModule],
  templateUrl: './restraints.html',
  styleUrl: './restraints.scss',
})
export class Restraints {}
