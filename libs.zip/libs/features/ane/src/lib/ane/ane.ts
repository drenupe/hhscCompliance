import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-ane',
  imports: [CommonModule],
  templateUrl: './ane.html',
  styleUrl: './ane.scss',
})
export class Ane {}
