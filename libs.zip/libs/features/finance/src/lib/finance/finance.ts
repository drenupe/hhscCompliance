import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-finance',
  imports: [CommonModule],
  templateUrl: './finance.html',
  styleUrl: './finance.scss',
})
export class Finance {}
