import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-protective-devices',
  imports: [CommonModule],
  templateUrl: './protective-devices.html',
  styleUrl: './protective-devices.scss',
})
export class ProtectiveDevices {}
