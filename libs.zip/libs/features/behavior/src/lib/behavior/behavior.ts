import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'lib-behavior',
  imports: [CommonModule],
  templateUrl: './behavior.html',
  styleUrl: './behavior.scss',
})
export class Behavior {}
