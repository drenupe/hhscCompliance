export * from './lib/behavior/behavior';
